#pragma once

#include <string>
#include <string_view>

#include <pl/Config.hpp>

namespace clange_me {

// User-facing settings. These are configuration only; they do not enable
// targeting until a verified Minecraft entity/camera backend is implemented.
struct ModConfig {
    int version = 2;
    bool enabled = true;
    float aimRange = 6.0f;
    float fovDegrees = 45.0f;
    bool showFov = true;
    std::string targetPart = "head";       // head, torso, legs
    std::string targetType = "players";    // players, mobs, both
    bool attackEnabled = false;
    bool ignoreCreative = true;
    bool ignoreSpectator = true;
};

nlohmann::json makeDefaultConfigJson();
nlohmann::json makeConfigSchemaJson();

} // namespace clange_me

template <> struct pl::config::Schema<clange_me::ModConfig> {
    static constexpr std::string_view title = "Aim Assist Config";
    static constexpr std::string_view description =
        "Settings for Aim Assist. Targeting remains inactive until the game backend is verified.";

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "version")
            return {.title = "Version", .readOnly = true};
        if (name == "enabled")
            return {.title = "Enabled", .description = "Master switch for aim assist."};
        if (name == "aimRange")
            return {.title = "Aim Range", .description = "Maximum target distance in blocks."};
        if (name == "fovDegrees")
            return {.title = "FOV", .description = "Aim selection field of view in degrees."};
        if (name == "showFov")
            return {.title = "Show FOV", .description = "Show or hide the FOV indicator."};
        if (name == "targetPart")
            return {.title = "Target Part", .description = "head, torso, or legs."};
        if (name == "targetType")
            return {.title = "Target Type", .description = "players, mobs, or both."};
        if (name == "attackEnabled")
            return {.title = "Attack", .description = "Allow attack actions; disabled by default."};
        if (name == "ignoreCreative")
            return {.title = "Ignore Creative", .description = "Exclude Creative-mode players."};
        if (name == "ignoreSpectator")
            return {.title = "Ignore Spectator", .description = "Exclude Spectator-mode players."};
        return {};
    }
};
